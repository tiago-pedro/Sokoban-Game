package pt.iscte.dcti.poo.sokoban.starter;
import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Position;

public abstract class AbstractObject implements ImageTile {

	public Position position; 
	public String name;

	public AbstractObject(Position position, String name){
		this.position = position;
		this.name = name;
	} 
	public String getName(){
		return name; 
	}
	public  Position getPosition(){
		return position;
	}

	public abstract int getLevel(); 
	public abstract boolean isTransposable(); 
	public abstract boolean isMovable(); 

	public boolean isBuraco(){
		return false;
	}
	public boolean isBatery(){
		return false; 
	}
	public boolean isPlayer(){
		return false; 
	}
	public boolean isCaixa(){
		return false;
	}
	public boolean isAlvo(){
		return false; 
	}
}