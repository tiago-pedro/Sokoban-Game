package pt.iscte.dcti.poo.sokoban.starter;
import java.awt.event.KeyEvent;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Observable;
import java.util.Observer;
import java.util.Scanner;

import javax.swing.JOptionPane;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.gui.ImageTile;
import pt.iul.ista.poo.utils.Position;

public class SokobanGame implements Observer {

	private Player player; 
	private ArrayList<AbstractObject> mapa = new ArrayList<AbstractObject>();
	private ArrayList<Pontua��o> tabela = new ArrayList<Pontua��o>();
	private String level; 
	private int moves; 
	private int subat;
	private String nickname; 
	private String score = ""; 

	private static SokobanGame INSTANCE = null; 

	public static SokobanGame getInstance(String level, String nickname) throws FileNotFoundException{
		if(INSTANCE == null){
			INSTANCE = new SokobanGame(level, nickname);		
		}
		return INSTANCE;
	}
	private SokobanGame(String level, String nickname) throws FileNotFoundException  {
		this.level = level;
		this.nickname = nickname;
		this.tabela = HighScore.HighScoreSave("levels/pontua�ao" + level.charAt(12) + ".txt");
		ImageMatrixGUI.getInstance().addImages(buildLevel(new File(level)));	
	}
	public ArrayList <ImageTile> buildLevel (File f){		//leitura de mapas 

		this.moves = 100;
		ArrayList<ImageTile> level = new ArrayList<ImageTile>();
		String line = "";
		for(int y=0; y!=10;y++)
			for(int x=0; x!=10; x++)
				level.add(new Chao (new Position(x,y))); 
		Scanner scanner;
		try {
			scanner = new Scanner(f);
			int aux = 0; 

			while(scanner.hasNextLine()){
				line = scanner.nextLine();

				for(int i=0; i<line.length();i++){
					AbstractObject o = ObjectFactory.createObject(line.charAt(i), i, aux, this);
					if(o.isPlayer()){
						player = (Player) o; 
					}
					level.add(o);
					mapa.add(o);	
				}
				aux ++; 
			}
			scanner.close(); 
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		return level;
	}
	@Override
	public void update(Observable arg0, Object arg1) {			//andar da empilhadora 
		int lastKeyPressed = (Integer) arg1;
		if(lastKeyPressed == KeyEvent.VK_R){
			this.restart();
		}
		if (player != null && moves != 0){
			player.move(lastKeyPressed);
			ImageMatrixGUI.getInstance().setStatusMessage("Nickname: " + nickname + " Level " + level.charAt(12) + " Moves: " + moves);
		}
		else{
			int r = JOptionPane.showConfirmDialog(null, nickname + " No moves left ! \n Restart?"); 
			if(r ==0){
				this.restart();
			}else{
				this.beginning();
			}
		}

		boolean restart = false; 

		for(AbstractObject m: mapa){
			if(m.isBuraco()){
				if(m.getPosition().equals(player.getPosition())){
					restart = true;
					ImageMatrixGUI.getInstance().removeImage(player);
				}else{
					for(AbstractObject e: mapa){
						if(e.isCaixa()){
							if(m.getPosition().equals(e.getPosition())){
								restart = true;
								ImageMatrixGUI.getInstance().removeImage(e);
							}
						}
					}
				}
			}
		}
		if(restart){
			Pontua��o p = new Pontua��o(nickname, 0);
			tabela.add(p);
			Collections.sort(tabela); 
			int i = JOptionPane.showConfirmDialog(null, nickname + "\n Retry?");
			if(i == 0){
				this.restart();
			}else{
				System.exit(0);
			}
		}
		if(checkLevel()){
			int a = 1000 + moves*250 - subat;
			if(a <0){
				a = 1000;
			}
			Pontua��o p = new Pontua��o(nickname, a);
			score += "\n" + p.toString(); 
			tabela.add(p);
			Collections.sort(tabela);
			HighScore.save(tabela, "levels/pontua�ao" + level.charAt(12) + ".txt");
			this.nextLevel();
		}
	}
	public boolean checkLevel (){				//confirma posi��o das caixas com os alvos
		List<Position> alvos = new ArrayList<Position>();
		List<Position> caixas = new ArrayList<Position>();

		for(AbstractObject m: mapa){
			if(m.isAlvo()){
				alvos.add(m.getPosition());
			}
		}
		for(AbstractObject e: mapa){
			if(e.isCaixa()){
				for(Position p: alvos){
					if(e.getPosition().equals(p)){
						caixas.add(e.getPosition());
					}
				}	
			}
		}
		return alvos.size() == caixas.size();	
	}
	public void beginning() {
		int a = 0; 
		level = "levels/level" + a + ".txt";
		ImageMatrixGUI.getInstance().clearImages();
		mapa.clear(); 
		tabela.clear();
		tabela = HighScore.HighScoreSave("levels/pontua�ao" + level.charAt(12) + ".txt");
		ImageMatrixGUI.getInstance().addImages(buildLevel(new File(level)));
		ImageMatrixGUI.getInstance().addObserver(this); 
		ImageMatrixGUI.getInstance().setStatusMessage("Nickname: " + nickname + "Level " + a + " Moves: " + moves);
		ImageMatrixGUI.getInstance().go();
		ImageMatrixGUI.getInstance().update();
	}
	public void restart() {
		sub(500);
		ImageMatrixGUI.getInstance().clearImages();
		mapa.clear();
		ImageMatrixGUI.getInstance().addImages(buildLevel(new File(level)));
		ImageMatrixGUI.getInstance().addObserver(this);
		ImageMatrixGUI.getInstance().setStatusMessage("Nickname:" + nickname + "Level " + level.charAt(12) + " Moves: " + moves);
		ImageMatrixGUI.getInstance().go();
		ImageMatrixGUI.getInstance().update();
	}
	public void nextLevel() {
		String c = "" + level.charAt(12);
		int a = Integer.parseInt(c);
		a++;
		File f = new File("levels/level" + a + ".txt");
		if(f.exists()){
			tabela = HighScore.HighScoreSave("levels/pontua�ao" + a + ".txt");
			level = "levels/level" + a + ".txt";
			ImageMatrixGUI.getInstance().clearImages();
			mapa.clear(); 
			ImageMatrixGUI.getInstance().addImages(buildLevel(f));
			ImageMatrixGUI.getInstance().addObserver(this); 
			ImageMatrixGUI.getInstance().setStatusMessage("Nickname: " + nickname + " Level " + a + " Moves: " + moves);
			ImageMatrixGUI.getInstance().go();
			ImageMatrixGUI.getInstance().update();
		}else{
			int i = JOptionPane.showConfirmDialog(null, "CONGRATULATIONS!!!" + score + "\n Play Again?");
			if(i == 0){
				nickname = JOptionPane.showInputDialog(null,"          Insert Nickname!       "); 
				score = ""; 
				this.beginning();
			}else{
				System.exit(0);
			}
		}
	}
	public ArrayList<AbstractObject> getMap() {
		return mapa;
	}
	public String getLevel(){
		return level; 
	}
	public int getMoves(){
		return moves; 
	}
	public void setMoves(int moves){
		this.moves = moves; 
	}
	public void movesdec(){
		moves--;
	}
	public String getNickname(){
		return nickname;
	}
	public void sub(int val){
		subat += val; 
	}
}