package pt.iscte.dcti.poo.sokoban.starter;
import pt.iul.ista.poo.utils.Position;

public class Alvo extends AbstractObject {

	public Alvo(Position initialPosition){
		super(initialPosition, "Alvo"); 
	}

	@Override
	public int getLevel() {
		return 0; 
	}
	@Override
	public boolean isTransposable() {
		return true;
	}
	@Override
	public boolean isMovable() {
		return false;
	}
	@Override
	public boolean isAlvo() {
		return true;
	}
}