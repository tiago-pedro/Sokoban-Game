package pt.iscte.dcti.poo.sokoban.starter;

import java.awt.event.KeyEvent;
import java.util.ArrayList;

import pt.iul.ista.poo.gui.*;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Position;

public class Player extends AbstractObject implements ActiveObject{

	private int level = 2;
	private SokobanGame mapa;

	public Player(Position initialPosition, SokobanGame mapa){
		super(initialPosition, "Empilhadora_U");
		this.mapa = mapa; 
	}

	@Override
	public void move(int t) {

		Direction[] possibleDirections = Direction.values();
		Position newPosition = new Position(0,0);

		if(t == KeyEvent.VK_LEFT || t == KeyEvent.VK_A){
			this.name = "Empilhadora_L"; 
			newPosition = position.plus(possibleDirections[0].asVector()); //esquerda 
		}
		else if (t == KeyEvent.VK_RIGHT || t == KeyEvent.VK_D){
			this.name = "Empilhadora_R"; 
			newPosition = position.plus(possibleDirections[2].asVector()); //direita 
		}
		else if (t == KeyEvent.VK_UP || t == KeyEvent.VK_W){
			this.name = "Empilhadora_U"; 
			newPosition = position.plus(possibleDirections[1].asVector()); //para cima 
		}
		else if (t == KeyEvent.VK_DOWN || t == KeyEvent.VK_S){
			this.name = "Empilhadora_D"; 
			newPosition = position.plus(possibleDirections[3].asVector()); //para baixo 
		}
		boolean b = true; 

		for(AbstractObject m : mapa.getMap()){
			if(m.isMovable()){
				if(newPosition.equals(m.getPosition())){
					((ActiveObject)m).move(t);
				}
			}
			if(m.isBatery()){
				if(newPosition.equals(m.getPosition())){
					ImageMatrixGUI.getInstance().removeImage(m);
					mapa.setMoves(mapa.getMoves()+10);
					mapa.sub(2500); 
				}
			}
		}
		if(Barreiras(newPosition , mapa.getMap()) && b == true){
			this.position = newPosition;
			mapa.movesdec();
		}
		ImageMatrixGUI.getInstance().update();
	}

	public boolean Barreiras(Position x, ArrayList<AbstractObject> mapa){
		boolean b = true;

		for(AbstractObject m: mapa){
			if(!m.isTransposable()){
				if(m.getPosition().equals(x)){
					b = false;
				}
			}
		} 
		return b;
	}
	@Override
	public int getLevel() {
		return level;
	}
	@Override
	public boolean isTransposable() {
		return true;
	}
	@Override
	public boolean isMovable() {
		return false;
	}
	@Override
	public boolean isPlayer() {
		return true;
	}
}