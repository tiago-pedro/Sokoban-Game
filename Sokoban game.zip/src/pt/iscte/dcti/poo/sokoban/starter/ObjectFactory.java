package pt.iscte.dcti.poo.sokoban.starter;

import pt.iul.ista.poo.utils.Position;

public class ObjectFactory {

	public static AbstractObject createObject (char c, int x, int y, SokobanGame g){
		AbstractObject s = null;
		Position p = new Position(x,y);

		if(c =='#') {
			s = new Parede(p);
		}else if(c == 'E'){
			s = new Player(p, g);
		}else if (c == 'b'){
			s = new Bateria(p); 
		}else if(c == 'O'){
			s = new Buraco(p);
		}else if(c == 'X'){
			s = new Alvo(p);
		}else if(c == 'C'){
			s = new Caixa(p, g);
		}else if (c == 'G'){
			s = new BigStone(p, g); 
		}else if (c == 'S'){
			s = new SmallStone(p, g);
		}else if (c == ' '){
			s = new Chao(p); 
		}
		return s;
	}
}