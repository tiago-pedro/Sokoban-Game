package pt.iscte.dcti.poo.sokoban.starter;

import java.awt.event.KeyEvent;
import java.util.ArrayList;

import pt.iul.ista.poo.gui.ImageMatrixGUI;
import pt.iul.ista.poo.utils.Direction;
import pt.iul.ista.poo.utils.Position;

public class SmallStone extends AbstractObject implements ActiveObject {

	private SokobanGame mapa;
	private boolean transposable = false; 

	public SmallStone(Position position, SokobanGame mapa) {
		super(position, "SmallStone");
		this.mapa = mapa; 
	}

	@Override
	public void move(int t) {
		Direction[] possibleDirections = Direction.values();
		Position newPosition = new Position(0,0);

		if(t == KeyEvent.VK_LEFT  || t == KeyEvent.VK_A){
			newPosition = position.plus(possibleDirections[0].asVector()); //esquerda 

		}
		else if (t == KeyEvent.VK_RIGHT || t == KeyEvent.VK_D){
			newPosition = position.plus(possibleDirections[2].asVector()); //direita 
		}
		else if (t ==  KeyEvent.VK_UP|| t == KeyEvent.VK_W){
			newPosition = position.plus(possibleDirections[1].asVector()); //cima 
		}
		else if (t ==KeyEvent.VK_DOWN|| t == KeyEvent.VK_S){
			newPosition = position.plus(possibleDirections[3].asVector()); //baixo 
		}
		for(AbstractObject m: mapa.getMap()){
			if(m.isBuraco()){
				if(newPosition.equals(m.getPosition())){
					ImageMatrixGUI.getInstance().removeImage(this);

				}
			}
		}
		if(Barreiras(newPosition, mapa.getMap())){
			position = newPosition; 
		}
		ImageMatrixGUI.getInstance().update();
	}

	public boolean Barreiras(Position x, ArrayList<AbstractObject> mapa){
		boolean b = true;

		for(AbstractObject m: mapa){
			if(!m.isTransposable() || m.isBatery()){
				if(m.getPosition().equals(x)){
					b = false; 
				}
			}
			if(m.isBuraco()){
				if(m.getPosition().equals(position)){
					transposable = true; 
					ImageMatrixGUI.getInstance().removeImage(this);
				}
			}
		}
		return b;
	}

	@Override
	public int getLevel() {
		return 1;
	}
	@Override
	public boolean isTransposable() {
		return transposable;
	}
	@Override
	public boolean isMovable() {
		return true;
	}
}