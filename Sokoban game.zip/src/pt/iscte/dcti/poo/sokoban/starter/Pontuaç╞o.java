package pt.iscte.dcti.poo.sokoban.starter;

public class Pontua��o implements Comparable<Pontua��o>{

	private String nome;
	private int points;

	public Pontua��o(String nome, int points){
		this.nome = nome; 
		this.points = points;
	}

	public int getPoints() {
		return points;
	}

	@Override			//collection sort
	public int compareTo(Pontua��o o) {
		int a = 0;
		if(points == o.getPoints()){
			return a;
		}else if(points > o.getPoints()) {
			a = -1;
		}else if(points < o.getPoints()){
			a = 1; 
		}
		return a;
	}

	@Override
	public String toString() {
		return nome + " Score: " + points;
	}
}