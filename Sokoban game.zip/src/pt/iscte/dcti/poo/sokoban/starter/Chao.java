package pt.iscte.dcti.poo.sokoban.starter;
import pt.iul.ista.poo.utils.Position;

public class Chao extends AbstractObject {

	public Chao(Position position){
		super(position, "Chao"); 
	}
	@Override
	public int getLevel() {
		return 0;
	}
	@Override
	public boolean isTransposable() {
		return true; 
	}
	@Override
	public boolean isMovable() {
		return false;
	}
}