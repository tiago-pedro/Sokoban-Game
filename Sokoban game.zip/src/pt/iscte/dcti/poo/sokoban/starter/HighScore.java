package pt.iscte.dcti.poo.sokoban.starter;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;

public class HighScore {

	public static void save(ArrayList<Pontua��o> tabela, String filepath) {
		PrintWriter p;
		try {
			p = new PrintWriter (new File(filepath));
			if(tabela.size()<5){
				for(int i=0; i<tabela.size(); i++){
					p.println(tabela.get(i).toString());
				}
			}else{
				for(int i =0; i<5; i++){
					p.println(tabela.get(i).toString());
				}
			}
			p.flush();
			p.close();
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}

	public static ArrayList<Pontua��o> HighScoreSave(String filepath){

		ArrayList<Pontua��o> scores = new ArrayList<Pontua��o>(); 

		try(Scanner sc = new Scanner(new File(filepath));){

			while(sc.hasNextLine()){
				String [] score = sc.nextLine().split(" "); 

				int b = Integer.parseInt(score[2]); 

				Pontua��o p = new Pontua��o(score[0], b);
				scores.add(p);
			}

		}catch (FileNotFoundException e){
			e.printStackTrace();
		}
		return scores; 
	}
}