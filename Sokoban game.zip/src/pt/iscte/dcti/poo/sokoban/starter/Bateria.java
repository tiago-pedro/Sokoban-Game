package pt.iscte.dcti.poo.sokoban.starter;
import pt.iul.ista.poo.utils.Position;

public class Bateria extends AbstractObject {

	public Bateria(Position initialPosition){
		super(initialPosition, "Bateria"); 
	}
	@Override
	public int getLevel() {
		return 2; 
	}
	@Override
	public boolean isTransposable() {
		return true;
	}
	@Override
	public boolean isMovable() {
		return false;
	}
	@Override
	public boolean isBatery() {
		return true;
	}
}