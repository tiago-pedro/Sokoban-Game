package pt.iscte.dcti.poo.sokoban.starter;

public interface ActiveObject {

	void move (int lastKeyPressed); 
}