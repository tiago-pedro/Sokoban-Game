package pt.iscte.dcti.poo.sokoban.starter;

import java.io.FileNotFoundException;

import javax.swing.JOptionPane;

import pt.iul.ista.poo.gui.ImageMatrixGUI;

public class Main {

	public static void main(String[] args) throws FileNotFoundException {

		String name = JOptionPane.showInputDialog(null, "       Insert Nickname       "); 
		while(name == null){
			name = JOptionPane.showInputDialog(null, "       Insert Nickname       "); 
		}
		SokobanGame s = SokobanGame.getInstance("levels/level0.txt", name);
		ImageMatrixGUI.getInstance().addObserver(s);
		ImageMatrixGUI.getInstance().go();
		ImageMatrixGUI.getInstance().setName("SokobanGame");
		ImageMatrixGUI.getInstance().setStatusMessage("Nickname: " + name + " Level 0 Moves: " + s.getMoves());
	}
}