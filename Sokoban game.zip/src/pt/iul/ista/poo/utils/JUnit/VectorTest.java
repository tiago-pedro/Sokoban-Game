package pt.iul.ista.poo.utils.JUnit;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import org.junit.BeforeClass;
import org.junit.Test;

import pt.iul.ista.poo.utils.Vector2D;


public class VectorTest {

	private static Vector2D a; 

	@BeforeClass
	public static void init(){
		a = new Vector2D(10,10);
		assertNotNull("A inst�ncia criada � nula", a); 
	}
	@Test
	public void testGetX() {
		int x = 6;
		Vector2D v1 = new Vector2D(x, 7);
		assertEquals(x, v1.getX());
	}
	@Test
	public void testGetY() {
		int y = 6;
		Vector2D v1 = new Vector2D(7,y);
		assertEquals(v1.getY(), y);
	}
	@Test
	public void testPlus1(){
		Vector2D a = new Vector2D(6,6); 
		Vector2D b = new Vector2D(3,3); 
		b = b.plus(new Vector2D(3,3));
		assertEquals(a.getX(), b.getX());
		assertEquals(a.getY(), b.getY()); 
	}
	@Test
	public void testPlus2(){
		Vector2D a = new Vector2D(-6,-6); 
		Vector2D b = new Vector2D(-3,-3); 
		b = b.plus(new Vector2D(-3,-3));
		assertEquals(a.getX(), b.getX());
		assertEquals(a.getY(), b.getY()); 
	}
	@Test
	public void testPlus3(){
		Vector2D a = new Vector2D(3,4); 
		Vector2D b = new Vector2D(3,4); 
		b = b.plus(new Vector2D(0,0));
		assertEquals(a.getX(), b.getX());
		assertEquals(a.getY(), b.getY()); 
	}
	@Test
	public void testSubt1(){
		Vector2D a = new Vector2D(6,6); 
		Vector2D b = new Vector2D(3,3); 
		a = a.minus(b);
		assertEquals(a.getX(), b.getX());
		assertEquals(a.getY(), b.getY()); 
	}
	@Test
	public void testSubt2(){
		a = new Vector2D(-8,-8); 
		Vector2D b = new Vector2D(-4,-4); 
		b = b.minus(new Vector2D(4,4));
		assertEquals(a.getX(), b.getX());
		assertEquals(a.getY(), b.getY()); 
	}
	@Test
	public void testSubt3(){
		Vector2D a = new Vector2D(-6,-5); 
		Vector2D b = new Vector2D(-6,-5); 
		b = b.minus(new Vector2D(0,0));
		assertEquals(a.getX(), b.getX());
		assertEquals(a.getY(), b.getY()); 
	}	
}
