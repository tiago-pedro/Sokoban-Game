package pt.iul.ista.poo.utils;

public class Vector2D {
	private int x;
	private int y;

	/**
	 * @param x horizontal coordinate
	 * @param y vertical coordinate
	 */
	public Vector2D(int x, int y) {
		this.x = x;
		this.y = y;
	}
	/**
	 * 
	 * Getter to the X horizontal coordinate of the vector whereupon it moves to a new position.
	 * 
	 * @return x.
	 */
	public int getX() {
		return x;
	}
	/**
	 *  Getter to the Y vertical coordinate of the vector whereupon it moves to a new position.
	 * 
	 * @return y.
	 */
	public int getY() {
		return y;
	}
	/**
	 * 
	 *
	 *Sum of the constructor vector with a new given vector: sum of X's horizontal coordinates 
	 *and Y's vertical coordinates.
	 * 
	 * @param v
	 * 
	 * @return newVector2D 
	 * 
	 */
	public Vector2D plus(Vector2D v) {
		return new Vector2D(getX() + v.getX(), getY() + v.getY());
	}
	/**
	 * 
	 *
	 *Subtraction of the constructor vector with a new given vector: subtraction of X's horizontal coordinates 
	 *and Y's vertical coordinates.
	 * 
	 * @param v
	 * 
	 * @return newVector2D 
	 * 
	 */
	public Vector2D minus(Vector2D v) {
		return new Vector2D(getX() - v.getX(), getY() - v.getY());
	}

	@Override
	public String toString() {
		return "<" + x + ", " + y + ">";
	}
}